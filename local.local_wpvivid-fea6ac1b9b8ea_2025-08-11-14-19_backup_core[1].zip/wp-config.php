<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'UgMz0:(9xfz!J_pDag1KPDt_.pFJ&pQiavX`[} GSQW4n>Dpogh:_mIdALes2.sZ' );
define( 'SECURE_AUTH_KEY',   'gKv` 30h#8M>xFw8}}wnC>F<>ObnvVE4C5r+$pqdt!e%Ao[{RlAHrC2V]2@}<T!~' );
define( 'LOGGED_IN_KEY',     '@GNEokr3l,G-(:rfK/=4`U.|4jR*Cahxvc|iM&Aj1L&X27l)FY!>T4IPcbxv~owV' );
define( 'NONCE_KEY',         'k4de1iFgW<Q~KIR<og&b:Oln,])5.UQn: 1y !U-0tHG;g7e22C1!wfQ,?=r0I_O' );
define( 'AUTH_SALT',         '5$8~#:M:zu3Qd.l#X6v?k:g(o/!$wL2 sc#oD1DZ>A~{{`y o5Mb1cunr}GBG1g%' );
define( 'SECURE_AUTH_SALT',  'k0Y1;?kd/R^eTRefmBFcybH3QYEqRR@U)x$)}y]yb3dB?k.d|.Fi9r(]tB>J2_$v' );
define( 'LOGGED_IN_SALT',    '~-qzg<n-Q~C{J^ST[<~~_~(T]yD/4yH).i2O]FP1/fCkXv Vq!^=isZjzmM5 3c+' );
define( 'NONCE_SALT',        'vC#}ZuNBcDJ(uf}TS|$axSFoK(A[Aq^.@3<X|Y=SELB9?[j`QrE^oPDF  &{NF7l' );
define( 'WP_CACHE_KEY_SALT', 'ckdP}4c/CzPUb=1.(;%FuT-~<ODCb9/rkz>9(w7oC*v1Q6|llYQNizM S/TyLx,v' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
